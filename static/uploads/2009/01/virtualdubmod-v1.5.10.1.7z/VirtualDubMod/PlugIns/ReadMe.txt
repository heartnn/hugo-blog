Filter plugins (*.vdf) placed here are automatically loaded
by VirtualDub on startup.
