<?php
/*
Plugin Name: External Link New Tab
Plugin URI: http://heartnn.tk/typecho_svn/index.php/archives/73/
Description: ��վ��������������ҳ��򿪵Ĺ��ܣ������� rel="external" ���� target="_blank" ��ʹҳ�����strict��׼��
Author: Heartnn
Version: 1.0
Author URI: http://heartnn.tk
*/

/* Insert JS snippet */
add_action('wp_head', 'external_links_insert_js');
function external_links_insert_js() {

//Only load on front-end pages
if (!is_admin()):
echo <<<JS

<script type="text/javascript">
	/* <![CDATA[ */
	//Add target="_blank" to external site and replace target="_blank" in all links of rel="external" , by http://heartnn.tk
	function externalLinks() {
		if (!document.getElementsByTagName) return;
		var anchors = document.getElementsByTagName("a");
		for (var i=0; i<anchors.length; i++) {
			var anchor = anchors[i];
			if (anchor.getAttribute("href") && (anchor.getAttribute("rel") == "external"))
			anchor.target = "_blank";
		}
	}
	window.onload = function() {externalLinks();}
	/* ]]> */
</script>

JS;
endif;
}

$images_new_window = true;

function url_domain_name($url){
	preg_match("/^(http:\/\/)?([^\/]+)/i", $url, $match);
	$host = $match[2];
	preg_match("/[^\.\/]+\.[^\.\/]+$/", $host, $match);
	return $match[0];
}

function external_image($url) {

	$chain=strtolower($url);
	if ((strpos($chain, '.jpg') > 0) || (strpos($chain, '.gif') > 0) || (strpos($chain, '.png') > 0))
	{
		return true;
	}
	return false;
}

function parse_external_link($match){
	global $images_new_window;

	if (($images_new_window && external_image($match[3])) || ( url_domain_name($matches[3]) != url_domain_name($_SERVER["HTTP_HOST"]) )) {
		return '<a href="' . $match[2] . '//' . $match[3] . '"' . $match[1] . $match[4] . ' rel="external">' . $match[5] . '</a>';
	} else {
		return '<a href="' . $match[2] . '//' . $match[3] . '"' . $match[1] . $match[4] . '>' . $match[5] . '</a>';
	}
}

function external_link($text) {

	$pattern = '/<a (.*?)href="(.*?)\/\/(.*?)"(.*?)>(.*?)<\/a>/i';
	$text = preg_replace_callback($pattern,'parse_external_link',$text);

	return $text;
}

add_filter('the_content', 'external_link', 999);
add_filter('the_excerpt', 'external_link', 999);
add_filter('comment_text', 'external_link', 999);
?>