#!/sbin/sh

busybox cp /system/bin/dnsmasq /system/bin/dnsmasq.orig